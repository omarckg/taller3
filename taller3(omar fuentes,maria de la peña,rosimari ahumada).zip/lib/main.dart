import 'package:flutter/material.dart';
import 'package:flutterapp/tallerapp/generatedhomepagewidget/GeneratedHomePageWidget.dart';
import 'package:flutterapp/tallerapp/generatedzapatoblancowidget/GeneratedZapatoBlancoWidget.dart';

void main() {
  runApp(tallerApp());
}

class tallerApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/GeneratedHomePageWidget',
      routes: {
        '/GeneratedHomePageWidget': (context) => GeneratedHomePageWidget(),
        '/GeneratedZapatoBlancoWidget': (context) =>
            GeneratedZapatoBlancoWidget(),
      },
    );
  }
}
